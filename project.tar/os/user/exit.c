// immediately exit without printing anything
#include <inc/lib.h>

void
umain(int argc, char **argv)
{
}
