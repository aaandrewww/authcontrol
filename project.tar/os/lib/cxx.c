extern "C" {
unsigned __cxa_atexit() {
	return 0;
}

unsigned __dso_handle() {
	return 0;
}
}
